package Clickevent;

public interface Subcat_clickevent {
    public void GetItempos (int pos);
}
