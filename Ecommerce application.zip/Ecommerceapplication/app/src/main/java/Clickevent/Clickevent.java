package Clickevent;

public interface Clickevent {
    public void GetItemPos(int pos);
}
