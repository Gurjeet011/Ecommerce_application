package com.example.ecommerceapplication;

public class Modelclass {


    private int id;

    public int getId() {
        return id;
    }

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    private int sid;

    public void setId(int id) {
        this.id = id;
    }

    public String getImageslider() {
        return imageslider;
    }

    public void setImageslider(String imageslider) {
        this.imageslider = imageslider;
    }

    private String imageslider;
    private String categoreyname;

    public String getCategoreyname() {
        return categoreyname;
    }

    public void setCategoreyname(String categoreyname) {
        this.categoreyname = categoreyname;
    }

    public String getCategoreyimage() {
        return categoreyimage;
    }

    public void setCategoreyimage(String categoreyimage) {
        this.categoreyimage = categoreyimage;
    }

    private String categoreyimage;


    private String Subcatimages;
    private String Subcattext;

    public String getSubcatimages() {
        return Subcatimages;
    }

    public void setSubcatimages(String subcatimages) {
        Subcatimages = subcatimages;
    }

    public String getSubcattext() {
        return Subcattext;
    }

    public void setSubcattext(String subcattext) {
        Subcattext = subcattext;
    }

    private String Productimages;
    private String itemproduct;
    private String originalprice;
    private String discountprice;
    private String brandname;
    private String description;

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    private int pid;

    public String getProductimages() {
        return Productimages;
    }

    public void setProductimages(String productimages) {
        Productimages = productimages;
    }

    public String getItemproduct() {
        return itemproduct;
    }

    public void setItemproduct(String itemproduct) {
        this.itemproduct = itemproduct;
    }

    public String getOriginalprice() {
        return originalprice;
    }

    public void setOriginalprice(String originalprice) {
        this.originalprice = originalprice;
    }

    public String getDiscountprice() {
        return discountprice;
    }

    public void setDiscountprice(String discountprice) {
        this.discountprice = discountprice;
    }

    public String getBrandname() {
        return brandname;
    }

    public void setBrandname(String brandname) {
        this.brandname = brandname;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    private String desimage;
    private String desname;
    private String desdes;
    private String despriceori;
    private String despricedis;
    private int did;

    public String getDesname() {
        return desname;
    }

    public void setDesname(String desname) {
        this.desname = desname;
    }

    public String getDesdes() {
        return desdes;
    }

    public void setDesdes(String desdes) {
        this.desdes = desdes;
    }

    public String getDespriceori() {
        return despriceori;
    }

    public void setDespriceori(String despriceori) {
        this.despriceori = despriceori;
    }

    public String getDespricedis() {
        return despricedis;
    }

    public void setDespricedis(String despricedis) {
        this.despricedis = despricedis;
    }

    public int getDid() {
        return did;
    }

    public void setDid(int did) {
        this.did = did;
    }

    public String getDesimage() {
        return desimage;
    }

    public void setDesimage(String desimage) {
        this.desimage = desimage;
    }
}
