package com.example.ecommerceapplication;

public class SliderPagerAdapter {
}
