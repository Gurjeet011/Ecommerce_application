package com.example.ecommerceapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Handler;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import Clickevent.Clickevent;
import adapter.Home_category_adapter;
import adapter.ImageSliderAdapter;

public class Home_fragment extends Fragment {

    Home_category_adapter home_category_adapter;
    ImageSliderAdapter imageSliderAdapter;




    RequestQueue queue,queue2;
    ArrayList<Modelclass> arrayList,arrayList2;
    RecyclerView  recyclerViewww;
    ViewPager2 viewPager;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home_fragment, container, false);
        viewPager = view.findViewById(R.id.viewPager);
        arrayList2 = new ArrayList<>();

        String slider = "http://www.gurjeetsingh.store/webservice1.asmx/Home_imagesliderapi";
        queue2 = Volley.newRequestQueue(getContext());

        StringRequest stringRequest2 = new StringRequest(Request.Method.GET, slider,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            //    Toast.makeText(getContext(), "kkkkkk" + response, Toast.LENGTH_LONG).show();

                            JSONArray jsonArray = new JSONArray(response);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                Modelclass modelclass = new Modelclass();
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String images = "http://www.gurjeetsingh.store/upload/" + jsonObject.getString("image");
                                modelclass.setImageslider(images);
                                arrayList.add(modelclass);
                                imageSliderAdapter  = new ImageSliderAdapter(getContext(), arrayList);
                                viewPager.setAdapter(imageSliderAdapter);
                                final Handler handler = new Handler();
                                final Runnable updateSlider = new Runnable() {
                                    public void run() {
                                        int currentPage = viewPager.getCurrentItem();
                                        int totalItems = imageSliderAdapter.getItemCount();
                                        int nextPage = (currentPage + 1) % totalItems;
                                        viewPager.setCurrentItem(nextPage, true);
                                        handler.postDelayed(this, 1000); // Change image every 3 seconds (adjust as needed)
                                    }
                                };
                                handler.postDelayed(updateSlider, 1000); // Delayed start of auto-sliding (adjust as needed)


                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });


























        queue = Volley.newRequestQueue(getContext());
        recyclerViewww = view.findViewById(R.id.recycleview2);
        arrayList = new ArrayList<>();

        String categoryurl = "http://www.gurjeetsingh.store/webservice1.asmx/CategoryApi";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, categoryurl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                        //    Toast.makeText(getContext(), "kkkkkk" + response, Toast.LENGTH_LONG).show();

                            JSONArray jsonArray = new JSONArray(response);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                Modelclass modelclass = new Modelclass();
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                int id=jsonObject.getInt("catid");
                                String name = jsonObject.getString("Catname");
                                String image = "http://www.gurjeetsingh.store/upload/" + jsonObject.getString("catimage");
                                modelclass.setCategoreyname(name);
                                modelclass.setCategoreyimage(image);
                                modelclass.setId(id);
                                arrayList.add(modelclass);
                                home_category_adapter = new Home_category_adapter(getContext(), arrayList);
                                recyclerViewww.setAdapter(home_category_adapter);
                                LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
                                recyclerViewww.setLayoutManager(layoutManager);
                                home_category_adapter.setonItemClickForRec(new Clickevent() {
                                    @Override
                                    public void GetItemPos(int pos) {
                                      getFragmentManager().beginTransaction().replace(R.id.second, new Cat_subcategory(arrayList.get(pos).getId())).addToBackStack(null).commit();
                                      //  Context context;
                                       /* Intent intent = new Intent(getContext(), Cat_subcategory.class);
                                        getContext() .startActivity(intent);*/



                                    }
                                });
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });

// Add the request to the RequestQueue.
        queue.add(stringRequest);
queue2.add(stringRequest2);
        return view;
    }







}