package com.example.ecommerceapplication;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import Clickevent.Clickevent;
import adapter.Description_adapter;
import adapter.Product_adapter;

public class Description extends Fragment {
    Description_adapter description_adapter;
    RequestQueue queue;
    ArrayList<Modelclass> arrayList;
    RecyclerView desrecycler;
    int pos;
    public Description(int pos) {
        // Required empty public constructor
        this.pos = pos;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_description, container, false);
        queue = Volley.newRequestQueue(getContext());
        desrecycler = view.findViewById(R.id.description);
        arrayList = new ArrayList<>();



        String url = "http://www.gurjeetsingh.store/webservice1.asmx/productdesapi?id="+pos;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            //   Toast.makeText(getContext(), "bbbbbbbbbbbb" + response, Toast.LENGTH_LONG).show();

                            JSONArray jsonArray = new JSONArray(response);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                Modelclass modelclass = new Modelclass();
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                int pid = jsonObject.getInt("did");
                                //  String quantity = jsonObject.getString("quantity");
                                String name = jsonObject.getString("bname");
                                String oriprice = jsonObject.getString("oriprice");
                                String disprice = jsonObject.getString("disprice");
                                String des = jsonObject.getString("desname");

                                String image = "http://www.gurjeetsingh.store/upload/" + jsonObject.getString("desimage");
                                modelclass.setDesname(name);
                                // modelclass.setItemproduct(quantity);
                                modelclass.setDespriceori(oriprice);
                                modelclass.setDespricedis(disprice);
                                modelclass.setDesdes(des);

                                modelclass.setDesimage(image);
                                modelclass.setDid(pid);
                                arrayList.add(modelclass);

                                description_adapter = new Description_adapter(getContext(), arrayList);
                                desrecycler.setAdapter(description_adapter);
                                GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 1);
                                desrecycler.setLayoutManager(layoutManager);
                               /* desrecycler.setonItemClickForRec(new Clickevent() {
                                    @Override
                                    public void GetItemPos(int pos) {
                                        getFragmentManager().beginTransaction().replace(R.id.third, new Description(arrayList.get(pos).getPid())).addToBackStack(null).commit();
                                        Toast.makeText(getContext(), "jjjjj", Toast.LENGTH_SHORT).show();
                                    }


                                });*/


                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText( getContext(), "error", Toast.LENGTH_SHORT).show();
            }
        });

// Add the request to the RequestQueue.

        queue.add(stringRequest);



        return  view;
    }
}