package com.example.ecommerceapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.ecommerceapplication.Cat_subcategory;
import com.example.ecommerceapplication.R;
/*

public class Subcat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        String oo = getIntent().getStringExtra("hlo");

        // Check if the extra is not null before using it
       // if (itemIdExtra != null) {
            // Use the extra to initialize the Cat_subcategory fragment
            getSupportFragmentManager().beginTransaction().add(R.id.nho, new Cat_subcategory("hlo").commit();
        }
    }

*/

