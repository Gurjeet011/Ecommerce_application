package com.example.ecommerceapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import Clickevent.Clickevent;
import Clickevent.Subcat_clickevent;
import adapter.Sub_cat_adapter;

public class Cat_subcategory extends Fragment {
    Sub_cat_adapter sub_cat_adapter;
    RequestQueue queue3;
    ArrayList<Modelclass> arrayList3;
    RecyclerView recyclerviwsubcat;


    int pos;
    public Cat_subcategory(int pos) {
        // Required empty public constructor
        this.pos=pos;




    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=getLayoutInflater().inflate(R.layout.fragment_cat_subcategory,null,false);

      //  View view= inflater.inflate(R.layout.fragment_cat_subcategory, container, false);
     // TextView textView=view.findViewById(R.id.iddemo);
     //   textView.setText(""+pos);
        Toolbar toolbar = view.findViewById(R.id.toolbar);
        AppCompatActivity activity = (AppCompatActivity) getActivity();
        activity.setSupportActionBar(toolbar);
        activity.getSupportActionBar().setTitle("Products");

        activity.getSupportActionBar().setDisplayHomeAsUpEnabled(true); // Enable the back arrow

        // Set the click listener for the back arrow
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to the previous Fragment
                getActivity().onBackPressed();
            }
        });
        queue3 = Volley.newRequestQueue(getContext());
        recyclerviwsubcat = view.findViewById(R.id.recycleviewSub_cat);
        arrayList3 = new ArrayList<>();

        String url = "http://www.gurjeetsingh.store/webservice1.asmx/Subcategoryapi?id="+pos;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                         //   Toast.makeText(getContext(), "sucess" + response, Toast.LENGTH_LONG).show();

                            JSONArray jsonArray = new JSONArray(response);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                Modelclass modelclass = new Modelclass();
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                               int sid=jsonObject.getInt("sid");
                                String name = jsonObject.getString("name");
                                String image = "http://www.gurjeetsingh.store/upload/" + jsonObject.getString("image");
                                modelclass.setSubcatimages(name);
                                modelclass.setSubcattext(image);
                                modelclass.setSid(sid);
                                arrayList3.add(modelclass);
                                sub_cat_adapter = new Sub_cat_adapter(getContext(), arrayList3);
                                recyclerviwsubcat.setAdapter(sub_cat_adapter);
                                LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
                                recyclerviwsubcat.setLayoutManager(layoutManager);
                               sub_cat_adapter.setonItemClickForRec(new Clickevent() {
                                   @Override
                                   public void GetItemPos(int pos) {
                                       getFragmentManager().beginTransaction().replace(R.id.second, new Product(arrayList3.get(pos).getSid())).addToBackStack(null).commit();

                                   }


                                });


                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText( getContext(), "error", Toast.LENGTH_SHORT).show();
            }
        });

// Add the request to the RequestQueue.

        queue3.add(stringRequest);

        return view;
    }
}